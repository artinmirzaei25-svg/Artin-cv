let root = document.documentElement;
const $ = document;
let themeToggle = $.querySelector(".theme-toggle");
let savedTheme = localStorage.getItem("theme");
if (savedTheme) {
  root.dataset.theme = savedTheme;
} else {
  delete root.dataset.theme;
}
function chnge() {
  let nextTheme = root.dataset.theme === "light" ? "dark" : "light";
  let label = `Switch to ${nextTheme} theme`;
  themeToggle.setAttribute("aria-label", label);
  themeToggle.title = label;
}
chnge();

themeToggle.addEventListener("click", () => {
  let nextTheme = root.dataset.theme === "light" ? "dark" : "light";
  root.dataset.theme = nextTheme;
  localStorage.setItem("theme", nextTheme);
  chnge();
});

let textHello = $.querySelector(".hello_text_in_main");
let BoldName = $.querySelector(".h1_myname");
let MYjob = $.querySelector(".my_job_text");
let ArtinText = $.querySelector(".h1_myname_in_header");
setTimeout(() => {
  textHello.style.opacity = "1";
}, 100);

setTimeout(() => {
  BoldName.style.opacity = "1";
  BoldName.style.transform = "translateX(0px)";
}, 300);

setTimeout(() => {
  MYjob.style.opacity = "1";
  MYjob.style.transform = "translateX(0px)";
}, 300);
setTimeout(() => {
  ArtinText.style.opacity = "1";
}, 200);

let observer = new IntersectionObserver((entries, currentObserver) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("show");
      currentObserver.unobserve(entry.target);
    }
  });
});

document.querySelectorAll(".reveal, .h2_Github").forEach((element) => {
  observer.observe(element);
});

let DivOpt = $.querySelector(".div_input_sherch");
let inputSherchBar = $.getElementById("SherchBar");

DivOpt.addEventListener("click", () => {
  inputSherchBar.focus();
});

let page2 = $.getElementById("page2");
let page1 = $.getElementById("page1");
let btnreturnPage = $.getElementById("buttonreturnPage");
btnreturnPage.addEventListener("click", () => {
  page1.style.display = "grid";
  page2.style.display = "none";
  page1.closest(".div__myproject").scrollIntoView({
    block: "start",
  });
});

let btnnextPage = $.getElementById("buttonNextPage");
btnnextPage.addEventListener("click", () => {
  page1.style.display = "none";
  page2.style.display = "grid";
});

document.body.classList.toggle("english");

let observer1 = new IntersectionObserver((entries, currentObserver) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("show1");
      currentObserver.unobserve(entry.target);
    }
  });
});

document.querySelectorAll(".shape1, .animeit_shape").forEach((element) => {
  observer1.observe(element);
});

let observer2 = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("shpae_show");
      observer.unobserve(entry.target);
    }
  });
});

document.querySelectorAll(".shape").forEach((element) => {
  observer2.observe(element);
});
let observer3 = new IntersectionObserver((entries, observer) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("myproject_show");
      observer.unobserve(entry.target);
    }
  });
});

document.querySelectorAll(".div_main_myprojec").forEach((element) => {
  observer3.observe(element);
});
